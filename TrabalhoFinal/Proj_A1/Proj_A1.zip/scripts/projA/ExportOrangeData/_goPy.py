import os
os.system( "_go00_CREATE_VIEWS.bat" )
os.system( "_go01_EXPORT.bat" )