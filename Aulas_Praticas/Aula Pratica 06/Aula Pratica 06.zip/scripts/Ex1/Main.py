import pandas, numpy, sklearn

def main():
    print('pandas: {}'.format(pandas.__version__))
    print('numpy: {}'.format(numpy.__version__))
    print('sklearn: {}'.format(sklearn.__version__))

if __name__ == "__main__":
    main()